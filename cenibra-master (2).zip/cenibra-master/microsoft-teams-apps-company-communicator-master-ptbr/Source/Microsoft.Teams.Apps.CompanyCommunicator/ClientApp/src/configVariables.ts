export const getBaseUrl = (): string => {
    return window.location.origin;
}
